#
# Copyright vekair
#
__version__ = '0.1.6'
__VERSION__ = __version__
from .generate_excel import generate_excel